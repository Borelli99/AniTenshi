
	YūzōnōYū@cbec121aa82ebb02aaa73806992e0368a97d47b5451ed6524816d03084c45905"9
https://yuzono.github.iohttps://discord.gg/85MZhUX688���
�

AnimeOnsen1eu.kanade.tachiyomi.animeextension.all.animeonsen�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.animeonsen-v14.10.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.animeonsen.png"14(
214.108J7՟������v
AnimeOnsenall"https://www.animeonsen.xyz
�
AnimeWorld India6eu.kanade.tachiyomi.animeextension.all.animeworldindia�
nhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.animeworldindia-v14.24.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.animeworldindia.png"14(214.248J9�Щ�����AnimeWorld Indiaall"https://anime-world.coJ8�ԋ����AnimeWorld Indiabn"https://anime-world.coJ8�̎�����oAnimeWorld Indiaen"https://anime-world.coJ8�Ғ�����lAnimeWorld Indiahi"https://anime-world.coJ8��䄫��� AnimeWorld Indiaja"https://anime-world.coJ8������׬&AnimeWorld Indiaml"https://anime-world.coJ8�������fAnimeWorld Indiamr"https://anime-world.coJ8ӧ������|AnimeWorld Indiata"https://anime-world.coJ8�������yAnimeWorld Indiate"https://anime-world.co
�
AnimeXin/eu.kanade.tachiyomi.animeextension.all.animexin�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.animexin-v14.32.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.animexin.png"14( 214.328J/��鎘���@AnimeXinall"https://animexin.dev
�
AniZone.eu.kanade.tachiyomi.animeextension.all.anizone�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.anizone-v16.15.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.anizone.png"16(216.158J,���ᾓ�AniZoneall"https://anizone.to
�
ChineseAnime3eu.kanade.tachiyomi.animeextension.all.chineseanime�
khttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.chineseanime-v14.36.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.chineseanime.png"14($214.368J:�Ρ�����wChineseAnimeall"https://www.chineseanime.in
�
Debrid Index2eu.kanade.tachiyomi.animeextension.all.debridindex�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.debridindex-v14.2.apkhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.debridindex.png"14(214.28J:�������Debrid Indexall"https://torrentio.strem.fun
�
Google Drive2eu.kanade.tachiyomi.animeextension.all.googledrive�
jhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.googledrive-v14.18.apkhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.googledrive.png"14(214.188J7��ʨ����:Google Driveall"https://drive.google.com
�
GoogleDriveIndex7eu.kanade.tachiyomi.animeextension.all.googledriveindex�
nhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.googledriveindex-v14.7.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.googledriveindex.png"14(214.78J!���Ž��hGoogleDriveIndexall
�
Hentai Torrent (Torrent)4eu.kanade.tachiyomi.animeextension.all.hentaitorrent�
khttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.hentaitorrent-v14.5.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.hentaitorrent.png"14(214.58@JIӂ��޶��FHentai Torrent (Torrent)all"https://www.hentaitorrents.com
�
Jable,eu.kanade.tachiyomi.animeextension.all.jable�
chttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.jable-v14.2.apkyhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.jable.png"14(214.28J'��������DJablezh"https://jable.tvJ'簭ޚ���Jableen"https://jable.tvJ'�д�����eJableja"https://jable.tv
�
JavGG,eu.kanade.tachiyomi.animeextension.all.javgg�
dhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.javgg-v14.22.apkyhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.javgg.png"14(214.228J)�������.JavGGall"https://javgg.net
�
Jav Guru.eu.kanade.tachiyomi.animeextension.all.javguru�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.javguru-v14.47.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.javguru.png"14(/214.478J+��������vJav Guruall"https://jav.guru
�
Jellyfin/eu.kanade.tachiyomi.animeextension.all.jellyfin�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.jellyfin-v16.32.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.jellyfin.png"16( 216.328J�ރҪ���}Jellyfin (1)allJ����˦��DJellyfin (2)allJ������hJellyfin (3)all
�
LMAnime.eu.kanade.tachiyomi.animeextension.all.lmanime�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.lmanime-v14.30.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.lmanime.png"14(214.308J-���ګ�ؠeLMAnimeall"https://lmanime.com
�
MissAV-eu.kanade.tachiyomi.animeextension.all.missav�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.missav-v14.33.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.missav.png"14(!214.338J,̐ǫ㦓�MissAVall"https://missav.live
�
Movy+eu.kanade.tachiyomi.animeextension.all.movy�
bhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.movy-v16.3.apkxhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.movy.png"16(216.38J*��Ճ����{Movyall"https://www.movy.sx
�
MyReadingManga5eu.kanade.tachiyomi.animeextension.all.myreadingmanga�
lhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.myreadingmanga-v14.2.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.myreadingmanga.png"14(214.28J;ή놌���CMyReadingMangaar"https://myreadingmanga.infoJ;屹�����zMyReadingMangaid"https://myreadingmanga.infoJ;��ן����#MyReadingMangabg"https://myreadingmanga.infoJ>����ƴӁzMyReadingMangazh-hk"https://myreadingmanga.infoJ;���봚��sMyReadingMangazh"https://myreadingmanga.infoJ>��ҿ���QMyReadingMangazh-tw"https://myreadingmanga.infoJ;��������bMyReadingMangacs"https://myreadingmanga.infoJ;���Τ���JMyReadingMangada"https://myreadingmanga.infoJ;��ᛐ���WMyReadingMangaen"https://myreadingmanga.infoJ<�����ܓ�,MyReadingMangafil"https://myreadingmanga.infoJ;ɻ������MyReadingMangafi"https://myreadingmanga.infoJ;��������<MyReadingManganl"https://myreadingmanga.infoJ;���е���MyReadingMangafr"https://myreadingmanga.infoJ;����ԥ�MyReadingMangade"https://myreadingmanga.infoJ;�������zMyReadingMangael"https://myreadingmanga.infoJ;��������HMyReadingMangahe"https://myreadingmanga.infoJ;���ѵʴ�{MyReadingMangahi"https://myreadingmanga.infoJ;�潂����xMyReadingMangahu"https://myreadingmanga.infoJ;��������.MyReadingMangait"https://myreadingmanga.infoJ;�ب�����iMyReadingMangaja"https://myreadingmanga.infoJ;��ݪ����sMyReadingMangako"https://myreadingmanga.infoJ;�ꬭ�ݐ�MyReadingMangams"https://myreadingmanga.infoJ;���ˉ�uMyReadingMangano"https://myreadingmanga.infoJ;��Ɣ�܃MyReadingMangapl"https://myreadingmanga.infoJ>􄕆�ՠ�bMyReadingMangapt-BR"https://myreadingmanga.infoJ;���޼��MyReadingMangaro"https://myreadingmanga.infoJ;�����ռ:MyReadingMangaru"https://myreadingmanga.infoJ;�筦Ќ��1MyReadingMangaes"https://myreadingmanga.infoJ;Γ������CMyReadingMangasv"https://myreadingmanga.infoJ;������MyReadingMangath"https://myreadingmanga.infoJ;П�ݻ���MyReadingMangatr"https://myreadingmanga.infoJ;�ؙ���9MyReadingMangavi"https://myreadingmanga.info
�

Newgrounds1eu.kanade.tachiyomi.animeextension.all.newgrounds�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.newgrounds-v14.1.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.newgrounds.png"14(214.18J7����̫
Newgroundsall"https://www.newgrounds.com
�
Nyaa (Torrent)2eu.kanade.tachiyomi.animeextension.all.nyaatorrent�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.nyaatorrent-v14.5.apkhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.nyaatorrent.png"14(214.58@J0����躺�INyaa (Torrent)all"https://nyaa.siJAѕ����~Nyaa Sukebein (Torrent)all"https://sukebei.nyaa.si
�
PTorrent (Torrent)/eu.kanade.tachiyomi.animeextension.all.ptorrent�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.ptorrent-v14.5.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.ptorrent.png"14(214.58@J>��������"PTorrent (Torrent)all"https://www.ptorrents.com
�
RouVideo/eu.kanade.tachiyomi.animeextension.all.rouvideo�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.rouvideo-v14.15.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.rouvideo.png"14(214.158J2�ߘ�����e	肉視頻all"https://rou.video/homeJ1�ǀ���ӄT	肉視頻zh"https://rou.video/homeJ1����̾˲	肉視頻en"https://rou.video/homeJ1�ϩ����q	肉視頻vi"https://rou.video/home
�
StreamingCommunity9eu.kanade.tachiyomi.animeextension.all.streamingcommunity�
qhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.streamingcommunity-v14.24.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.streamingcommunity.png"14(214.248JB���ȅ���	StreamingUnity (Movie)en"https://streamingunity.funJB�疓����StreamingUnity (Movie)it"https://streamingunity.funJ?�����΍�StreamingUnity (Tv)en"https://streamingunity.funJ?ļՌ�Ũ�dStreamingUnity (Tv)it"https://streamingunity.fun
�
Stremio.eu.kanade.tachiyomi.animeextension.all.stremio�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.stremio-v16.13.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.stremio.png"16(216.138@J9�����ݖ�tStremioall"https://app.strem.io/shell-v4.4
�

Subsplease1eu.kanade.tachiyomi.animeextension.all.subsplease�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.subsplease-v14.8.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.subsplease.png"14(214.88@J3��������y
Subspleaseall"https://subsplease.org
�
SupJav-eu.kanade.tachiyomi.animeextension.all.supjav�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.supjav-v14.31.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.supjav.png"14(214.318J*��ԟ�։>SupJaven"https://supjav.comJ*�߂��ʥ�+SupJavja"https://supjav.comJ*���깗�%SupJavzh"https://supjav.com
�
Torbox-eu.kanade.tachiyomi.animeextension.all.torbox�
dhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.torbox-v14.1.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.torbox.png"14(214.18J/�������xTorboxall"https://api.torbox.app
�
Torrentio (Torrent / Debrid)0eu.kanade.tachiyomi.animeextension.all.torrentio�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.torrentio-v16.12.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.torrentio.png"16(216.128@JJ����ө��3Torrentio (Torrent / Debrid)all"https://torrentio.strem.fun
�
"Torrentio Anime (Torrent / Debrid)5eu.kanade.tachiyomi.animeextension.all.torrentioanime�
mhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.torrentioanime-v16.24.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.torrentioanime.png"16(216.248@JP��̤���g"Torrentio Anime (Torrent / Debrid)all"https://torrentio.strem.fun
�
Xnxx+eu.kanade.tachiyomi.animeextension.all.xnxx�
bhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.xnxx-v14.3.apkxhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.xnxx.png"14(214.38J+�����Xnxxall"https://www.xnxx.com
�
Xvideos.eu.kanade.tachiyomi.animeextension.all.xvideos�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.xvideos-v14.3.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.xvideos.png"14(214.38J1��̔��ȠoXvideosall"https://www.xvideos.com
�
YFantasy/eu.kanade.tachiyomi.animeextension.all.yfantasy�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-all.yfantasy-v16.3.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.all.yfantasy.png"16(216.38J.��������YFantasyall"https://yfantasy.me
�
Anime4up.eu.kanade.tachiyomi.animeextension.ar.anime4up�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-ar.anime4up-v14.81.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.ar.anime4up.png"14(Q214.818J2�������Anime4Upar"https://w1.anime4up.rest
�
Anime Blkom0eu.kanade.tachiyomi.animeextension.ar.animeblkom�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-ar.animeblkom-v14.30.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.ar.animeblkom.png"14(214.308J=�ħ�Ǐ��Oأنمي بالكومar"https://animeblkom.net
�
Animeiat.eu.kanade.tachiyomi.animeextension.ar.animeiat�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-ar.animeiat-v14.1.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.ar.animeiat.png"14(214.18J4��Ť����bAnimeiatar"https://api.animeiat.co/v1
�
AnimeLek.eu.kanade.tachiyomi.animeextension.ar.animelek�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-ar.animelek-v14.41.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.ar.animelek.png"14()214.418J-���槍Ț
AnimeLekar"https://animelek.me
�
Animerco.eu.kanade.tachiyomi.animeextension.ar.animerco�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-ar.animerco-v14.60.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.ar.animerco.png"14(<214.608J3��Զ���=Animercoar"https://zeta.animerco.org
�
	ArabAnime/eu.kanade.tachiyomi.animeextension.ar.arabanime�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-ar.arabanime-v14.2.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.ar.arabanime.png"14(214.28J4ᆎ�����j	ArabAnimear"https://www.arabanime.net
�
	Arab Seed.eu.kanade.tachiyomi.animeextension.ar.arabseed�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-ar.arabseed-v14.32.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.ar.arabseed.png"14( 214.328J2�Ë�𗸈?عرب سيدar"https://m.asd.homes
�
asia2tv-eu.kanade.tachiyomi.animeextension.ar.asia2tv�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-ar.asia2tv-v14.39.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.ar.asia2tv.png"14('214.398J/��������Asia2TVar"https://ww1.asia2tv.pw
�
Cimaleek.eu.kanade.tachiyomi.animeextension.ar.cimaleek�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-ar.cimaleek-v14.12.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.ar.cimaleek.png"14(214.128J6�������}سيما ليكar"https://m.cimaleek.to
�
Egy Dead-eu.kanade.tachiyomi.animeextension.ar.egydead�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-ar.egydead-v14.30.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.ar.egydead.png"14(214.308J/��׍����tEgy Deadar"https://egydead.space
�
FASELHD-eu.kanade.tachiyomi.animeextension.ar.faselhd�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-ar.faselhd-v14.31.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.ar.faselhd.png"14(214.318J?�������فاصل اعلانيar"https://www.faselhds.biz
�
Okanime-eu.kanade.tachiyomi.animeextension.ar.okanime�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-ar.okanime-v14.28.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.ar.okanime.png"14(214.288J0�ɣ�����Okanimear"https://www.okanime.xyz
�
Tuktuk Cinema2eu.kanade.tachiyomi.animeextension.ar.tuktukcinema�
jhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-ar.tuktukcinema-v14.11.apkhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.ar.tuktukcinema.png"14(214.118J>������fتوك توك سينماar"https://tuktukhd.com
�
	WIT ANIME.eu.kanade.tachiyomi.animeextension.ar.witanime�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-ar.witanime-v14.65.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.ar.witanime.png"14(A214.658J0��Ъ�Ӫ�|	WIT ANIMEar"https://witanime.cyou
�
FilmiFen.eu.kanade.tachiyomi.animeextension.bg.filmifen�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-bg.filmifen-v16.2.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.bg.filmifen.png"16(216.28J.٪������"FilmiFenbg"https://filmifen.com
�

Anime-Base/eu.kanade.tachiyomi.animeextension.de.animebase�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-de.animebase-v14.47.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.de.animebase.png"14(/214.478J2����޸��
Anime-Basede"https://anime-base.net
�
Anime-Loads0eu.kanade.tachiyomi.animeextension.de.animeloads�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-de.animeloads-v14.27.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.de.animeloads.png"14(214.278J5���҈Anime-Loadsde"https://www.anime-loads.org
�
Anime-Stream1eu.kanade.tachiyomi.animeextension.de.animestream�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-de.animestream-v14.2.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.de.animestream.png"14(214.28J5����ة�Anime-Streamde"https://anime-stream.to
�

AnimeToast0eu.kanade.tachiyomi.animeextension.de.animetoast�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-de.animetoast-v14.36.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.de.animetoast.png"14($214.368J5��٘�뽏!
AnimeToastde"https://www.animetoast.cc
�
AniWorld.eu.kanade.tachiyomi.animeextension.de.aniworld�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-de.aniworld-v14.41.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.de.aniworld.png"14()214.418J-��������sAniWorldde"https://aniworld.to
�

FilmPalast0eu.kanade.tachiyomi.animeextension.de.filmpalast�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-de.filmpalast-v14.28.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.de.filmpalast.png"14(214.288J1�÷ǵ���1
FilmPalastde"https://filmpalast.to
�
Kinoking.eu.kanade.tachiyomi.animeextension.de.kinoking�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-de.kinoking-v14.37.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.de.kinoking.png"14(%214.378J-��������Kinokingde"https://kinoking.cc
�
Kool*eu.kanade.tachiyomi.animeextension.de.kool�
bhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-de.kool-v14.27.apkwhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.de.kool.png"14(214.278J)��ӽ����MKoolde"https://www.kool.to
�
Moflix-Stream2eu.kanade.tachiyomi.animeextension.de.moflixstream�
jhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-de.moflixstream-v14.30.apkhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.de.moflixstream.png"14(214.308J8ʁ�����]Moflix-Streamde"https://moflix-stream.xyz
�
Movie4k-eu.kanade.tachiyomi.animeextension.de.movie4k�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-de.movie4k-v14.20.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.de.movie4k.png"14(214.208J/ߺ������CMovie4kde"https://movie4k.stream
�
Serienstream2eu.kanade.tachiyomi.animeextension.de.serienstream�
jhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-de.serienstream-v14.35.apkhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.de.serienstream.png"14(#214.358J5�������PSerienstreamde"https://serienstream.to
�
Anichi,eu.kanade.tachiyomi.animeextension.en.anichi�
dhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.anichi-v16.10.apkyhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.anichi.png"16(
216.108J)���ѐ�Anichien"https://anichi.to
�
AniDB+eu.kanade.tachiyomi.animeextension.en.anidb�
bhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.anidb-v16.8.apkxhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.anidb.png"16(216.88J3��Ϭ����1AniDBen"https://anilab2.amdapi.click
�
AniHQ+eu.kanade.tachiyomi.animeextension.en.anihq�
bhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.anihq-v16.4.apkxhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.anihq.png"16(216.48J'����뀝�4AniHQen"https://anihq.cc
�
Anikage-eu.kanade.tachiyomi.animeextension.en.anikage�
dhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.anikage-v14.8.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.anikage.png"14(214.88J+��ٲ����Anikageen"https://anikage.cc
�
Anikoto-eu.kanade.tachiyomi.animeextension.en.anikoto�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.anikoto-v16.10.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.anikoto.png"16(
216.108J-���ٰ̟�AAnikotoen"https://anikototv.to
�
AniKuro-eu.kanade.tachiyomi.animeextension.en.anikuro�
dhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.anikuro-v16.3.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.anikuro.png"16(216.38J+��������IAniKuroen"https://anikuro.to
�
AniList-eu.kanade.tachiyomi.animeextension.en.anilist�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.anilist-v16.15.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.anilist.png"16(216.158J+������ؐAniListen"https://anilist.co
�
AnimeGG-eu.kanade.tachiyomi.animeextension.en.animegg�
dhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.animegg-v14.2.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.animegg.png"14(214.28J0��ݜͤ��AnimeGGen"https://www.animegg.org
�
	AnimeKhor/eu.kanade.tachiyomi.animeextension.en.animekhor�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.animekhor-v14.30.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.animekhor.png"14(214.308J0��뼭���	AnimeKhoren"https://animekhor.org
�

Animenosub0eu.kanade.tachiyomi.animeextension.en.animenosub�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.animenosub-v14.31.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.animenosub.png"14(214.318J1��߾��إ]
Animenosuben"https://animenosub.to
�
	AnimePahe/eu.kanade.tachiyomi.animeextension.en.animepahe�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.animepahe-v16.56.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.animepahe.png"16(8216.568J/���ڡ���	AnimePaheen"https://animepahe.pw
�
AnimeParadise3eu.kanade.tachiyomi.animeextension.en.animeparadise�
jhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.animeparadise-v16.3.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.animeparadise.png"16(216.38J<����ǐ��.AnimeParadiseen"https://www.animeparadise.moe
�
	AnimeSogo/eu.kanade.tachiyomi.animeextension.en.animesogo�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.animesogo-v16.10.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.animesogo.png"16(
216.108J/��������u	AnimeSogoen"https://animesogo.to
�
	AnimeTake/eu.kanade.tachiyomi.animeextension.en.animetake�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.animetake-v16.21.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.animetake.png"16(216.218J/��鱑���g	AnimeTakeen"https://animetake.tv
�
	AnimeToki/eu.kanade.tachiyomi.animeextension.en.animetoki�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.animetoki-v16.1.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.animetoki.png"16(216.18J0��ˑ�㮩.	AnimeTokien"https://animetoki.com
�
AniPM+eu.kanade.tachiyomi.animeextension.en.anipm�
bhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.anipm-v16.7.apkxhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.anipm.png"16(216.78J%���靄��/AniPMen"https://ani.pm
�
AniWave (Unoriginal)-eu.kanade.tachiyomi.animeextension.en.aniwave�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.aniwave-v16.12.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.aniwave.png"16(216.128J:��������<AniWave (Unoriginal)en"https://animewave.to
�
AniWaves.ru.eu.kanade.tachiyomi.animeextension.en.aniwaves�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.aniwaves-v16.4.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.aniwaves.png"16(216.48J0ƞ������QAniWaves.ruen"https://aniwaves.ru
�
AsiaFlix.eu.kanade.tachiyomi.animeextension.en.asiaflix�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.asiaflix-v14.33.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.asiaflix.png"14(!214.338J.��©�׿�PAsiaFlixen"https://asiaflix.net
�

AV1Encodes0eu.kanade.tachiyomi.animeextension.en.av1encodes�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.av1encodes-v16.4.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.av1encodes.png"16(216.48J2������Љ
AV1Encodesen"https://av1encodes.com
�
BLZone,eu.kanade.tachiyomi.animeextension.en.blzone�
dhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.blzone-v14.10.apkyhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.blzone.png"14(
214.108J*➙��ʎ�BLZoneen"https://blzone.net
�
DonghuaStream3eu.kanade.tachiyomi.animeextension.en.donghuastream�
khttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.donghuastream-v14.32.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.donghuastream.png"14( 214.328J8�������ODonghuaStreamen"https://donghuastream.org
�
Gotaku,eu.kanade.tachiyomi.animeextension.en.gotaku�
chttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.gotaku-v16.7.apkyhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.gotaku.png"16(216.78J)Ơ����ÊHGotakuen"https://gotaku.to
�
haho.moe-eu.kanade.tachiyomi.animeextension.en.hahomoe�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.hahomoe-v14.10.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.hahomoe.png"14(
214.108J*��������3haho.moeen"https://haho.moe
�
	hanime.tv,eu.kanade.tachiyomi.animeextension.en.hanime�
dhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.hanime-v16.25.apkyhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.hanime.png"16(216.258J,��ǚ����$	hanime.tven"https://hanime.tv
�
HentaiHaven1eu.kanade.tachiyomi.animeextension.en.hentaihaven�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.hentaihaven-v16.9.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.hentaihaven.png"16(	216.98J4��������HentaiHavenen"https://hentaihaven.xxx
�

HentaiMama0eu.kanade.tachiyomi.animeextension.en.hentaimama�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.hentaimama-v16.9.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.hentaimama.png"16(	216.98J1��ڇ»��o
HentaiMamaen"https://hentaimama.io
�
	HexaWatch/eu.kanade.tachiyomi.animeextension.en.hexawatch�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.hexawatch-v16.8.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.hexawatch.png"16(216.88J*�������y	HexaWatchen"https://hexa.su
�
Hstream-eu.kanade.tachiyomi.animeextension.en.hstream�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.hstream-v14.12.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.hstream.png"14(214.128J,ᗫ��Ԑ�yHstreamen"https://hstream.moe
�
	Kayoanime/eu.kanade.tachiyomi.animeextension.en.kayoanime�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.kayoanime-v14.13.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.kayoanime.png"14(214.138J0�¤��Ǟ�	Kayoanimeen"https://kayoanime.com
�
KickAssAnime2eu.kanade.tachiyomi.animeextension.en.kickassanime�
jhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.kickassanime-v14.63.apkhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.kickassanime.png"14(?214.638J,���䖅��KickAssAnimeen"https://kaa.lt
�
KimoiTV-eu.kanade.tachiyomi.animeextension.en.kimoitv�
dhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.kimoitv-v14.1.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.kimoitv.png"14(214.18J,��������XKimoiTVen"https://kimoitv.com
�
KissKH,eu.kanade.tachiyomi.animeextension.en.kisskh�
dhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.kisskh-v16.10.apkyhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.kisskh.png"16(
216.108J*�������!KissKHen"https://kisskh.ovh
�
AnimeKai (Unoriginal)-eu.kanade.tachiyomi.animeextension.en.kotokai�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.kotokai-v16.10.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.kotokai.png"16(
216.108J<����މ�AnimeKai (Unoriginal)en"https://animekaitv.to
�
LuciferDonghua4eu.kanade.tachiyomi.animeextension.en.luciferdonghua�
lhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.luciferdonghua-v14.28.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.luciferdonghua.png"14(214.288J9��������LuciferDonghuaen"https://luciferdonghua.in
�
Mapple,eu.kanade.tachiyomi.animeextension.en.mapple�
chttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.mapple-v16.8.apkyhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.mapple.png"16(216.88J*�ҕ�ѷ��=Mappleen"https://mapple.fun
�
MKissa,eu.kanade.tachiyomi.animeextension.en.mkissa�
dhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.mkissa-v16.74.apkyhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.mkissa.png"16(J216.748J/��ظֹ��AMKissaen"https://mkissa.to/anime
�
	MoviesMod/eu.kanade.tachiyomi.animeextension.en.moviesmod�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.moviesmod-v16.4.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.moviesmod.png"16(216.48J2��������'
Movies Moden"https://moviesmod.zone
�
My Running Man2eu.kanade.tachiyomi.animeextension.en.myrunningman�
jhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.myrunningman-v14.12.apkhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.myrunningman.png"14(214.128J<��ᓲ���XMy Running Manen"https://www.myrunningman.com
�
123Anime6eu.kanade.tachiyomi.animeextension.en.onetwothreeanime�
mhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.onetwothreeanime-v14.4.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.onetwothreeanime.png"14(214.48J0Ӑ��123Animeen"https://123animehub.cc
�
Oppai Stream1eu.kanade.tachiyomi.animeextension.en.oppaistream�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.oppaistream-v16.7.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.oppaistream.png"16(216.78J2��������Oppai Streamen"https://oppai.stream
�
PinoyMoviePedia5eu.kanade.tachiyomi.animeextension.en.pinoymoviepedia�
mhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.pinoymoviepedia-v14.10.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.pinoymoviepedia.png"14(
214.108J;����ʊ��vPinoyMoviePediaen"https://pinoymoviepedia.ru
�
Re:ANIME-eu.kanade.tachiyomi.animeextension.en.reanime�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.reanime-v16.14.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.reanime.png"16(216.148J,�����ӥ�bRe:ANIMEen"https://reanime.to
�
Rule34Video1eu.kanade.tachiyomi.animeextension.en.rule34video�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.rule34video-v16.11.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.rule34video.png"16(216.118J4���뢅��Rule34Videoen"https://rule34video.com
�
Senshi,eu.kanade.tachiyomi.animeextension.en.senshi�
chttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.senshi-v16.5.apkyhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.senshi.png"16(216.58J)������Senshien"https://senshi.to
�

UHD Movies/eu.kanade.tachiyomi.animeextension.en.uhdmovies�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.uhdmovies-v14.19.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.uhdmovies.png"14(214.198J1�үɉ���
UHD Moviesen"https://uhdmovies.vip
�
UniqueStream2eu.kanade.tachiyomi.animeextension.en.uniquestream�
jhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.uniquestream-v16.10.apkhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.uniquestream.png"16(
216.108J<��������UniqueStreamen"https://anime.uniquestream.net
�
WcoAnimeDub1eu.kanade.tachiyomi.animeextension.en.wcoanimedub�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.wcoanimedub-v14.10.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.wcoanimedub.png"14(
214.108J7�٫�����wWcoAnimeDuben"https://www.wcoanimedub.tv
�
WcoAnimeSub1eu.kanade.tachiyomi.animeextension.en.wcoanimesub�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.wcoanimesub-v14.10.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.wcoanimesub.png"14(
214.108J7�����Ʋ�	WcoAnimeSuben"https://www.wcoanimesub.tv
�

WcoForever0eu.kanade.tachiyomi.animeextension.en.wcoforever�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.wcoforever-v14.10.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.wcoforever.png"14(
214.108J6�����ԅ�P
WcoForeveren"https://www.wcoforever.net
�
Wcofun,eu.kanade.tachiyomi.animeextension.en.wcofun�
dhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.wcofun-v14.24.apkyhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.wcofun.png"14(214.248J.�Ϙ����Wcofunen"https://www.wcoflix.tv
�
	WCOStream/eu.kanade.tachiyomi.animeextension.en.wcostream�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.wcostream-v14.15.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.wcostream.png"14(214.158J3�������9	WCOStreamen"https://www.wcostream.tv
�
WcoTv+eu.kanade.tachiyomi.animeextension.en.wcotv�
chttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.wcotv-v14.10.apkxhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.wcotv.png"14(
214.108J)������	WcoTven"https://www.wco.tv
�
XAnime,eu.kanade.tachiyomi.animeextension.en.xanime�
chttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-en.xanime-v16.5.apkyhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.en.xanime.png"16(216.58J)���Ҵ���-XAnimeen"https://xanime.me
�
AnimeAv1.eu.kanade.tachiyomi.animeextension.es.animeav1�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.animeav1-v16.7.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.animeav1.png"16(216.78J.������AnimeAv1es"https://animeav1.com
�
AnimeBum.eu.kanade.tachiyomi.animeextension.es.animebum�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.animebum-v14.22.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.animebum.png"14(214.228J2���Д��rAnimeBumes"https://www.animebum.net
�
Animejl-eu.kanade.tachiyomi.animeextension.es.animejl�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.animejl-v14.23.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.animejl.png"14(214.238J1��壮ĵ�(Animejles"https://www.anime-jl.net
�
AnimeLatinoHD3eu.kanade.tachiyomi.animeextension.es.animelatinohd�
khttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.animelatinohd-v14.56.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.animelatinohd.png"14(8214.568J<�݉���KAnimeLatinoHDes"https://www.animelatinohd.com
�

AnimeMovil0eu.kanade.tachiyomi.animeextension.es.animemovil�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.animemovil-v14.50.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.animemovil.png"14(2214.508J1ż������6
AnimeMoviles"https://animemeow.xyz
�
Animenix.eu.kanade.tachiyomi.animeextension.es.animenix�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.animenix-v14.27.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.animenix.png"14(214.278J.���񶡞�Animenixes"https://animenix.com
�
AnimeOnline.Ninja6eu.kanade.tachiyomi.animeextension.es.animeonlineninja�
nhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.animeonlineninja-v14.67.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.animeonlineninja.png"14(C214.678J@�ݨ�܍��&AnimeOnline.Ninjaes"https://ww3.animeonline.ninja
�

AnimeYT.es/eu.kanade.tachiyomi.animeextension.es.animeytes�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.animeytes-v14.32.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.animeytes.png"14( 214.328J.��������A
AnimeYT.eses"https://animeyt.es
�
AsiaLiveAction4eu.kanade.tachiyomi.animeextension.es.asialiveaction�
lhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.asialiveaction-v14.53.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.asialiveaction.png"14(5214.538J:��������OAsiaLiveActiones"https://asialiveaction.com
�
	az-animex.eu.kanade.tachiyomi.animeextension.es.azanimex�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.azanimex-v14.3.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.azanimex.png"14(214.38J4��������k	az-animexes"https://www.az-animex.com
�
BeatZ Anime0eu.kanade.tachiyomi.animeextension.es.beatzanime�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.beatzanime-v14.3.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.beatzanime.png"14(214.38J7����ݬ1BeatZ Animees"https://www.beatz-anime.net
�
Cine24h-eu.kanade.tachiyomi.animeextension.es.cine24h�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.cine24h-v14.26.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.cine24h.png"14(214.268J/�������Cine24hes"https://cine24h.online
�
CineCalidad1eu.kanade.tachiyomi.animeextension.es.cinecalidad�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.cinecalidad-v14.38.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.cinecalidad.png"14(&214.388J7�Թ����	CineCalidades"https://www.cinecalidad.ec
�
Cineplus1231eu.kanade.tachiyomi.animeextension.es.cineplus123�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.cineplus123-v14.24.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.cineplus123.png"14(214.248J4�������Cineplus123es"https://cineplus123.org
�
Cuevana-eu.kanade.tachiyomi.animeextension.es.cuevana�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.cuevana-v14.68.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.cuevana.png"14(D214.688J3ᢛ�����
Cuevana3Eues"https://wv3.cuevana3.eu
�

Cuevana3Ch/eu.kanade.tachiyomi.animeextension.es.cuevanach�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.cuevanach-v14.67.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.cuevanach.png"14(C214.678J3߽ʕ����o
Cuevana3Ches"https://ww1.cuevana3.ch
�
DeTodoPeliculas5eu.kanade.tachiyomi.animeextension.es.detodopeliculas�
mhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.detodopeliculas-v14.24.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.detodopeliculas.png"14(214.248J<�Ȩ�����EDeTodo Peliculases"https://detodopeliculas.nu
�
Doramasflix1eu.kanade.tachiyomi.animeextension.es.doramasflix�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.doramasflix-v14.54.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.doramasflix.png"14(6214.548J3�������Doramasflixes"https://doramasflix.in
�
	Doramasyt/eu.kanade.tachiyomi.animeextension.es.doramasyt�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.doramasyt-v14.41.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.doramasyt.png"14()214.418J4�Ƭ���ڥ	Doramasytes"https://www.doramasyt.com
�
EnNovelas (Dead)/eu.kanade.tachiyomi.animeextension.es.ennovelas�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.ennovelas-v14.28.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.ennovelas.png"14(214.288J5��������\	EnNovelases"https://l.ennovelas-tv.com
�
EstrenosDoramas5eu.kanade.tachiyomi.animeextension.es.estrenosdoramas�
mhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.estrenosdoramas-v14.21.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.estrenosdoramas.png"14(214.218J;���㿐��EstrenosDoramases"https://estrenosdoramas.es
�
FanPelis.eu.kanade.tachiyomi.animeextension.es.fanpelis�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.fanpelis-v14.26.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.fanpelis.png"14(214.268J-��������FanPelises"https://fanpelis.la
�
	FlixLatam/eu.kanade.tachiyomi.animeextension.es.flixlatam�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.flixlatam-v14.29.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.flixlatam.png"14(214.298J0�ᩖ�ǧ!	FlixLatames"https://flixlatam.com
�
Gnula+eu.kanade.tachiyomi.animeextension.es.gnula�
chttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.gnula-v14.52.apkxhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.gnula.png"14(4214.528J)뒗�����_Gnulaes"https://gnula.life
�
	Hackstore/eu.kanade.tachiyomi.animeextension.es.hackstore�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.hackstore-v14.43.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.hackstore.png"14(+214.438J3�Ղ�����	Hackstorees"https://www.hackstore.fo
�
Hentaijk.eu.kanade.tachiyomi.animeextension.es.hentaijk�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.hentaijk-v14.21.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.hentaijk.png"14(214.218J.��������@Hentaijkes"https://hentaijk.com
�
Hentaila.eu.kanade.tachiyomi.animeextension.es.hentaila�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.hentaila-v14.49.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.hentaila.png"14(1214.498J.������¼YHentailaes"https://hentaila.com
�
HentaiTk.eu.kanade.tachiyomi.animeextension.es.hentaitk�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.hentaitk-v14.30.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.hentaitk.png"14(214.308J.�͞�����kHentaiTkes"https://hentaitk.net
�
HomeCine.eu.kanade.tachiyomi.animeextension.es.homecine�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.homecine-v14.21.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.homecine.png"14(214.218J-�����AHomeCinees"https://homecine.cc
�
Jkanime-eu.kanade.tachiyomi.animeextension.es.jkanime�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.jkanime-v14.53.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.jkanime.png"14(5214.538J,��Έ�ݞ�SJkanimees"https://jkanime.net
�
Jkhentai.eu.kanade.tachiyomi.animeextension.es.jkhentai�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.jkhentai-v14.11.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.jkhentai.png"14(214.118J2�������QJkhentaies"https://www.jkhentai.net
�
Katanime.eu.kanade.tachiyomi.animeextension.es.katanime�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.katanime-v14.25.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.katanime.png"14(214.258J.��ˍ����#Katanimees"https://katanime.net
�

LACartoons0eu.kanade.tachiyomi.animeextension.es.lacartoons�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.lacartoons-v14.28.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.lacartoons.png"14(214.288J6�ν��͞9
LACartoonses"https://www.lacartoons.com
�
LaMovie-eu.kanade.tachiyomi.animeextension.es.lamovie�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.lamovie-v14.29.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.lamovie.png"14(214.298J)��µ��ʚKLaMoviees"https://la.movie
�
Latanime.eu.kanade.tachiyomi.animeextension.es.latanime�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.latanime-v14.44.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.latanime.png"14(,214.448J.��Ӡ����dLatanimees"https://latanime.org
�
LegionAnime1eu.kanade.tachiyomi.animeextension.es.legionanime�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.legionanime-v14.52.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.legionanime.png"14(4214.528J9��✙�ŇLegionAnimees"https://legionanime.club/api
�
	LocoPelis/eu.kanade.tachiyomi.animeextension.es.locopelis�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.locopelis-v14.41.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.locopelis.png"14()214.418J4�͇����j	LocoPelises"https://www.locopelis.com
�
MetroSeries1eu.kanade.tachiyomi.animeextension.es.metroseries�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.metroseries-v14.34.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.metroseries.png"14("214.348J9ܨܼ�ζ�MetroSerieses"https://www3.seriesmetro.net
�
MhdFlix-eu.kanade.tachiyomi.animeextension.es.mhdflix�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.mhdflix-v14.25.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.mhdflix.png"14(214.258J0��Ƙɞ��BMhdFlixes"https://ww1.mhdflix.com
�
MonosChinos1eu.kanade.tachiyomi.animeextension.es.monoschinos�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.monoschinos-v14.57.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.monoschinos.png"14(9214.578J3�͕�ߺ��`MonosChinoses"https://monoschinos.st
�
MundoDonghua2eu.kanade.tachiyomi.animeextension.es.mundodonghua�
jhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.mundodonghua-v14.47.apkhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.mundodonghua.png"14(/214.478J:������<MundoDonghuaes"https://www.mundodonghua.com
�
Pandrama.eu.kanade.tachiyomi.animeextension.es.pandrama�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.pandrama-v14.12.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.pandrama.png"14(214.128J.�Հ�򱖇sPandramaes"https://pandrama.com
�

PelisForte0eu.kanade.tachiyomi.animeextension.es.pelisforte�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.pelisforte-v14.53.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.pelisforte.png"14(5214.538J6����Θ�=
PelisFortees"https://www2.pelisforte.se
�
PelisPlusHD1eu.kanade.tachiyomi.animeextension.es.pelisplushd�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.pelisplushd-v14.95.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.pelisplushd.png"14(_214.958J3�ش�ׯ��PelisPlusHDes"https://pelisplushd.bz
�
PelisPlusPh1eu.kanade.tachiyomi.animeextension.es.pelisplusph�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.pelisplusph-v14.95.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.pelisplusph.png"14(_214.958J7�������DPelisPlusPhes"https://www.pelisplushd.la
�
PelisPlusTo1eu.kanade.tachiyomi.animeextension.es.pelisplusto�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.pelisplusto-v14.95.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.pelisplusto.png"14(_214.958J0궮˚���PelisPlusToes"https://tioplus.app
�
Samato's Den: Videos5eu.kanade.tachiyomi.animeextension.es.samatodenvideos�
lhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.samatodenvideos-v14.1.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.samatodenvideos.png"14(214.18JDٌ��讙�}Samato's Den: Videoses"https://samatoden.blogspot.com
�
	SeriesKao/eu.kanade.tachiyomi.animeextension.es.serieskao�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.serieskao-v14.25.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.serieskao.png"14(214.258J0̟������	SeriesKaoes"https://serieskao.top
�

SoloLatino0eu.kanade.tachiyomi.animeextension.es.sololatino�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.sololatino-v14.29.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.sololatino.png"14(214.298J2�����Ϫ�%
SoloLatinoes"https://sololatino.net
�
	TioanimeH/eu.kanade.tachiyomi.animeextension.es.tioanimeh�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.tioanimeh-v14.39.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.tioanimeh.png"14('214.398J.�֝��Ҁ�+TioAnimees"https://tioanime.comJ0���빿��
	TioHentaies"https://tiohentai.com
�
Tiodonghua.com0eu.kanade.tachiyomi.animeextension.es.tiodonghua�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.tiodonghua-v14.27.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.tiodonghua.png"14(214.278J<��������^Tiodonghua.comes"https://anime.tiodonghua.com
�
	VeoHentai/eu.kanade.tachiyomi.animeextension.es.veohentai�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.veohentai-v14.1.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.veohentai.png"14(214.18J0ѝ������	VeoHentaies"https://veohentai.com
�
	VerAni.me.eu.kanade.tachiyomi.animeextension.es.veranime�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.veranime-v14.7.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.veranime.png"14(214.78J,�����"	VerAni.mees"https://verani.me
�
	VerAnimes/eu.kanade.tachiyomi.animeextension.es.veranimes�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.veranimes-v14.26.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.veranimes.png"14(214.268J4˄�����V	VerAnimeses"https://wwv.veranimes.net
�
VerPelisTop1eu.kanade.tachiyomi.animeextension.es.verpelistop�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.verpelistop-v14.14.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.verpelistop.png"14(214.148J6�����qVerPelisTopes"https://www1.verpelis.top
�
VerSeriesOnline5eu.kanade.tachiyomi.animeextension.es.verseriesonline�
mhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.verseriesonline-v14.22.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.verseriesonline.png"14(214.228J@���䠛��oVerSeriesOnlinees"https://www.verseriesonline.net
�
	zeroanime/eu.kanade.tachiyomi.animeextension.es.zeroanime�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.zeroanime-v14.15.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.zeroanime.png"14(214.158J5��������	zeroanimees"https://www4.zeroanime.xyz
�
	Zonaleros/eu.kanade.tachiyomi.animeextension.es.zonaleros�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-es.zonaleros-v14.20.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.es.zonaleros.png"14(214.208J5�������g	Zonaleroses"https://www.zona-leros.com
�

Anime-Sama/eu.kanade.tachiyomi.animeextension.fr.animesama�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-fr.animesama-v14.33.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.fr.animesama.png"14(!214.338J1􀜁����U
Anime-Samafr"https://anime-sama.to
�
AnimeVostFr1eu.kanade.tachiyomi.animeextension.fr.animevostfr�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-fr.animevostfr-v14.2.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.fr.animevostfr.png"14(214.28J3���҆���MAnimeVostFrfr"https://animevostfr.tv
�
EmpireStreaming5eu.kanade.tachiyomi.animeextension.fr.empirestreaming�
mhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-fr.empirestreaming-v14.30.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.fr.empirestreaming.png"14(214.308J:���ۮ�EmpireStreamingfr"https://empire-stream.net
�
FRAnime-eu.kanade.tachiyomi.animeextension.fr.franime�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-fr.franime-v14.29.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.fr.franime.png"14(214.298J+�����ۡ�*FRAnimefr"https://franime.fr
�
French Anime1eu.kanade.tachiyomi.animeextension.fr.frenchanime�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-fr.frenchanime-v14.35.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.fr.frenchanime.png"14(#214.358J6Ʌ������pFrench Animefr"https://french-anime.com
�
HDS)eu.kanade.tachiyomi.animeextension.fr.hds�
ahttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-fr.hds-v14.21.apkvhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.fr.hds.png"14(214.218J*�߯���,HDSfr"https://on1.hds.quest
�
JetAnime.eu.kanade.tachiyomi.animeextension.fr.jetanime�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-fr.jetanime-v14.24.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.fr.jetanime.png"14(214.248J3�纐����{JetAnimefr"https://ssl.jetanimes.com
�
MyKdrama.eu.kanade.tachiyomi.animeextension.fr.mykdrama�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-fr.mykdrama-v14.21.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.fr.mykdrama.png"14(214.218J-ѝ�����jMyKdramafr"https://mykdrama.co
�
OtakuFR-eu.kanade.tachiyomi.animeextension.fr.otakufr�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-fr.otakufr-v14.44.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.fr.otakufr.png"14(,214.448J+�Դ����OtakuFRfr"https://otakufr.cc
�
	Voiranime/eu.kanade.tachiyomi.animeextension.fr.voiranime�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-fr.voiranime-v14.3.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.fr.voiranime.png"14(214.38J0���֮���J	Voiranimefr"https://voir-anime.to
�
VoirCartoon1eu.kanade.tachiyomi.animeextension.fr.voircartoon�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-fr.voircartoon-v14.20.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.fr.voircartoon.png"14(214.208J4�������[VoirCartoonfr"https://voircartoon.com
�
Vostfree.eu.kanade.tachiyomi.animeextension.fr.vostfree�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-fr.vostfree-v14.43.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.fr.vostfree.png"14(+214.438J-�ᯯӥwVostfreefr"https://vostfree.ws
�
Wiflix,eu.kanade.tachiyomi.animeextension.fr.wiflix�
dhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-fr.wiflix-v14.31.apkyhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.fr.wiflix.png"14(214.318J,���ߝ��cWiflixfr"https://flemmix.best
�
YoMovies.eu.kanade.tachiyomi.animeextension.hi.yomovies�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-hi.yomovies-v14.35.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.hi.yomovies.png"14(#214.358J/��ݳ����"YoMovieshi"https://yomovies.town
�
	AnimeIndo/eu.kanade.tachiyomi.animeextension.id.animeindo�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-id.animeindo-v14.32.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.id.animeindo.png"14( 214.328J1�ܫ���ك	AnimeIndoid"https://animeindo.skin
�

Kuramanime0eu.kanade.tachiyomi.animeextension.id.kuramanime�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-id.kuramanime-v14.24.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.id.kuramanime.png"14(214.248J5Ν߼����@
Kuramanimeid"https://v8.kuramanime.tel
�
Kuronime.eu.kanade.tachiyomi.animeextension.id.kuronime�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-id.kuronime-v14.13.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.id.kuronime.png"14(214.138J2��ꢯ���Kuronimeid"https://tv1.kuronime.vip
�
	MiniOppai/eu.kanade.tachiyomi.animeextension.id.minioppai�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-id.minioppai-v14.19.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.id.minioppai.png"14(214.198J0�������/	MiniOppaiid"https://minioppai.org
�
NeoNime-eu.kanade.tachiyomi.animeextension.id.neonime�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-id.neonime-v14.27.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.id.neonime.png"14(214.278J,�ۺ���\NeoNimeid"https://neonime.ink
�
NimeGami.eu.kanade.tachiyomi.animeextension.id.nimegami�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-id.nimegami-v14.7.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.id.nimegami.png"14(214.78J-�蟧���6NimeGamiid"https://nimegami.id
�
Oploverz.eu.kanade.tachiyomi.animeextension.id.oploverz�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-id.oploverz-v16.29.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.id.oploverz.png"16(216.298J/�������#Oploverzid"https://oploverz.site
�
	OtakuDesu/eu.kanade.tachiyomi.animeextension.id.otakudesu�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-id.otakudesu-v14.44.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.id.otakudesu.png"14(,214.448J1�����ڛ�/	OtakuDesuid"https://otakudesu.blog
�

Samehadaku0eu.kanade.tachiyomi.animeextension.id.samehadaku�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-id.samehadaku-v14.10.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.id.samehadaku.png"14(
214.108J5�ל����g
Samehadakuid"https://v2.samehadaku.how
�
Anime Saturn1eu.kanade.tachiyomi.animeextension.it.animesaturn�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-it.animesaturn-v14.15.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.it.animesaturn.png"14(214.158J4��廧���AnimeSaturnit"https://animesaturn.net
�

AnimeUnity0eu.kanade.tachiyomi.animeextension.it.animeunity�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-it.animeunity-v14.9.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.it.animeunity.png"14(	214.98J5֏��ݲ��k
AnimeUnityit"https://www.animeunity.so
�
ANIMEWORLD.tv0eu.kanade.tachiyomi.animeextension.it.animeworld�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-it.animeworld-v16.61.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.it.animeworld.png"16(=216.618J8ة�٣���[ANIMEWORLD.tvit"https://www.animeworld.ac
�
AniPlay-eu.kanade.tachiyomi.animeextension.it.aniplay�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-it.aniplay-v14.23.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.it.aniplay.png"14(214.238J+��Ʀ����~AniPlayit"https://aniplay.co
�
Hentai Saturn2eu.kanade.tachiyomi.animeextension.it.hentaisaturn�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-it.hentaisaturn-v14.5.apkhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.it.hentaisaturn.png"14(214.58J:�������PHentaiSaturnit"https://www.hentaisaturn.com
�

Toonitalia0eu.kanade.tachiyomi.animeextension.it.toonitalia�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-it.toonitalia-v14.38.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.it.toonitalia.png"14(&214.388J4�����{
Toonitaliait"https://toonitalia.green
�
VVVVID,eu.kanade.tachiyomi.animeextension.it.vvvvid�
chttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-it.vvvvid-v14.1.apkyhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.it.vvvvid.png"14(214.18J-�������sVVVVIDit"https://www.vvvvid.it
�
Aniweek-eu.kanade.tachiyomi.animeextension.ko.aniweek�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-ko.aniweek-v14.19.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.ko.aniweek.png"14(214.198J,��֡��?Aniweekko"https://aniweek.com
�
desu-online0eu.kanade.tachiyomi.animeextension.pl.desuonline�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pl.desuonline-v14.22.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pl.desuonline.png"14(214.228J3�������Sdesu-onlinepl"https://desu-online.pl
�
Docchi,eu.kanade.tachiyomi.animeextension.pl.docchi�
dhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pl.docchi-v16.17.apkyhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pl.docchi.png"16(216.178J)�ƤԨ���Docchipl"https://docchi.pl
�
OgladajAnime2eu.kanade.tachiyomi.animeextension.pl.ogladajanime�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pl.ogladajanime-v14.5.apkhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pl.ogladajanime.png"14(214.58J5���޳���OgladajAnimepl"https://ogladajanime.pl
�

Anime Fire/eu.kanade.tachiyomi.animeextension.pt.animefire�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pt.animefire-v16.10.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pt.animefire.png"16(
216.108J4ݡ��(
Anime Firept-BR"https://animefire.one
�
AnimeIto.eu.kanade.tachiyomi.animeextension.pt.animeito�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pt.animeito-v16.18.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pt.animeito.png"16(216.188J4��������LAnimeitopt-BR"https://animesonline.io
�
	AnimePlay/eu.kanade.tachiyomi.animeextension.pt.animeplay�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pt.animeplay-v14.8.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pt.animeplay.png"14(214.88J6����͔7
Anime Playpt-BR"https://animeplay.cloud
�
AnimePlayer1eu.kanade.tachiyomi.animeextension.pt.animeplayer�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pt.animeplayer-v14.10.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pt.animeplayer.png"14(
214.108J:뒊����YAnimePlayerpt-BR"https://animeplayer.com.br
�
AnimeQ,eu.kanade.tachiyomi.animeextension.pt.animeq�
chttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pt.animeq-v14.9.apkyhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pt.animeq.png"14(	214.98J/�ׅ�����2AnimeQpt-BR"https://animeq.cloud
�
Animes Digital3eu.kanade.tachiyomi.animeextension.pt.animesdigital�
khttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pt.animesdigital-v16.10.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pt.animesdigital.png"16(
216.108J<���᏾��CAnimes Digitalpt-BR"https://animesdigital.org
�
AnimesDrive1eu.kanade.tachiyomi.animeextension.pt.animesdrive�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pt.animesdrive-v14.11.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pt.animesdrive.png"14(214.118J:��٭����UAnimes Drivept-BR"https://animesdrive.cloud
�
Animes Online CC4eu.kanade.tachiyomi.animeextension.pt.animesonlinecc�
khttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pt.animesonlinecc-v14.7.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pt.animesonlinecc.png"14(214.78J>����׋��fAnimes Online CCpt-BR"https://animesonlinecc.to
�
AnimesOnlineCloud7eu.kanade.tachiyomi.animeextension.pt.animesonlinecloud�
ohttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pt.animesonlinecloud-v14.10.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pt.animesonlinecloud.png"14(
214.108JBٷ������`Animes Online Cloudpt-BR"https://animesonline.cloud
�
Anitube-eu.kanade.tachiyomi.animeextension.pt.anitube�
ehttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pt.anitube-v14.31.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pt.anitube.png"14(214.318J3�������Anitubept-BR"https://www.anitube.vip
�
BetterAnimeIo3eu.kanade.tachiyomi.animeextension.pt.betteranimeio�
jhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pt.betteranimeio-v14.4.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pt.betteranimeio.png"14(214.48J8�������!BetterAnimeIopt-BR"https://betteranime.io
�
DattebayoBR1eu.kanade.tachiyomi.animeextension.pt.dattebayobr�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pt.dattebayobr-v14.1.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pt.dattebayobr.png"14(214.18J=�Φ�����Dattebayo BRpt-BR"https://www.dattebayo-br.com
�
Donghua no Sekai4eu.kanade.tachiyomi.animeextension.pt.donghuanosekai�
khttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pt.donghuanosekai-v14.4.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pt.donghuanosekai.png"14(214.48J?Ʒ������Donghua no Sekaipt-BR"https://donghuanosekai.com
�
Doramogo.eu.kanade.tachiyomi.animeextension.pt.doramogo�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pt.doramogo-v14.21.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pt.doramogo.png"14(214.218J1�������Doramogopt-BR"https://doramogo.com
�
Fun Anime TV0eu.kanade.tachiyomi.animeextension.pt.funanimetv�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pt.funanimetv-v14.2.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pt.funanimetv.png"14(214.28J:��������mFun Anime TVpt-BR"https://betterclass.click
�
Goyabu,eu.kanade.tachiyomi.animeextension.pt.goyabu�
chttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pt.goyabu-v14.7.apkyhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pt.goyabu.png"14(214.78J,��������Goyabupt-BR"https://goyabu.io
�
Meus Animes0eu.kanade.tachiyomi.animeextension.pt.meusanimes�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pt.meusanimes-v14.1.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pt.meusanimes.png"14(214.18J6��ӻ����tMeus Animespt-BR"https://meusanimes.vip
�
Muito Hentai1eu.kanade.tachiyomi.animeextension.pt.muitohentai�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pt.muitohentai-v14.2.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pt.muitohentai.png"14(214.28J<�������Muito Hentaipt-BR"https://www.muitohentai.com
�

Pi Fansubs/eu.kanade.tachiyomi.animeextension.pt.pifansubs�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pt.pifansubs-v14.35.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pt.pifansubs.png"14(#214.358J5��������"
Pi Fansubspt-BR"https://pifansubs.club
�
SmartAnimes1eu.kanade.tachiyomi.animeextension.pt.smartanimes�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pt.smartanimes-v14.9.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pt.smartanimes.png"14(	214.98J7����嫰cSmartAnimespt-BR"https://smartanimes.net
�
SushiAnimes1eu.kanade.tachiyomi.animeextension.pt.sushianimes�
hhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-pt.sushianimes-v14.2.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.pt.sushianimes.png"14(214.28J;��ڟЫ��*Sushi Animespt-BR"https://sushianimes.com.br
�
AnimeGO.studio-eu.kanade.tachiyomi.animeextension.ru.animego�
dhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-ru.animego-v16.2.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.ru.animego.png"16(216.28J6�������AnimeGO.studioru"https://animego.studio
�
Animelib.eu.kanade.tachiyomi.animeextension.ru.animelib�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-ru.animelib-v14.18.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.ru.animelib.png"14(214.188J1���㸋��Animelibru"https://animelib.org/ru
�
	Animevost/eu.kanade.tachiyomi.animeextension.ru.animevost�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-ru.animevost-v14.10.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.ru.animevost.png"14(
214.108J0ڨ������\	Animevostru"https://animevost.orgJ5������̊_Animevost Mirrorru"https://v13.vost.pw
�
Jutsu TV+eu.kanade.tachiyomi.animeextension.ru.jutsu�
bhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-ru.jutsu-v16.3.apkxhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.ru.jutsu.png"16(216.38J*��􌤳��>Jutsu TVru"https://jutsu.tv
�
HDRezka+eu.kanade.tachiyomi.animeextension.ru.rezka�
bhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-ru.rezka-v16.1.apkxhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.ru.rezka.png"16(216.18J+�߁�����'HDRezkaru"https://hdrezka.me
�

YummyAnime0eu.kanade.tachiyomi.animeextension.ru.yummyanime�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-ru.yummyanime-v16.4.apk}https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.ru.yummyanime.png"16(216.48J2��������T
YummyAnimeru"https://ru.yummyani.me
�
AnimeBalkan1eu.kanade.tachiyomi.animeextension.sr.animebalkan�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-sr.animebalkan-v14.19.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.sr.animebalkan.png"14(214.198J4���䔽��AnimeBalkansr"https://animebalkan.org
�
Anime Srbija1eu.kanade.tachiyomi.animeextension.sr.animesrbija�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-sr.animesrbija-v14.24.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.sr.animesrbija.png"14(214.248J9��հ����
Anime Srbijasr"https://www.animesrbija.com
�
Animeler.eu.kanade.tachiyomi.animeextension.tr.animeler�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-tr.animeler-v14.37.apk{https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.tr.animeler.png"14(%214.378J-��ҐԨ��[Animelertr"https://animeler.pw
�
Anizm+eu.kanade.tachiyomi.animeextension.tr.anizm�
chttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-tr.anizm-v14.47.apkxhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.tr.anizm.png"14(/214.478J(���ގ���+Anizmtr"https://anizm.net
�
AsyaAnimeleri3eu.kanade.tachiyomi.animeextension.tr.asyaanimeleri�
khttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-tr.asyaanimeleri-v14.27.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.tr.asyaanimeleri.png"14(214.278J8�޽�ܿ�AsyaAnimeleritr"https://asyaanimeleri.top
�
HDFilmCehennemi5eu.kanade.tachiyomi.animeextension.tr.hdfilmcehennemi�
mhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-tr.hdfilmcehennemi-v14.35.apk�https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.tr.hdfilmcehennemi.png"14(#214.358J?ƅ������aHDFilmCehennemitr"https://www.hdfilmcehennemi.nl
�
	TRAnimeCI/eu.kanade.tachiyomi.animeextension.tr.tranimeci�
ghttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-tr.tranimeci-v14.10.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.tr.tranimeci.png"14(
214.108J0ȶǚ͵��Q	TRAnimeCItr"https://tranimaci.com
�
TR Anime Izle1eu.kanade.tachiyomi.animeextension.tr.tranimeizle�
ihttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-tr.tranimeizle-v14.39.apk~https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.tr.tranimeizle.png"14('214.398J9��臮�ݘ$TR Anime Izletr"https://www.tranimeizle.io
�
UAKino,eu.kanade.tachiyomi.animeextension.uk.uakino�
chttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-uk.uakino-v14.6.apkyhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.uk.uakino.png"14(214.68J+ʷ��賫�UAKinouk"https://uakino.best
�
UFDub+eu.kanade.tachiyomi.animeextension.uk.ufdub�
bhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-uk.ufdub-v14.1.apkxhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.uk.ufdub.png"14(214.18J.�έ�����8UFDubuk"https://ufdub.com/anime
�
	Anime1.me,eu.kanade.tachiyomi.animeextension.zh.anime1�
chttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-zh.anime1-v14.4.apkyhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.zh.anime1.png"14(214.48J1��Ϋ����p	Anime1.mezh-hant"https://anime1.me
�
Cycity,eu.kanade.tachiyomi.animeextension.zh.cycity�
chttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-zh.cycity-v14.3.apkyhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.zh.cycity.png"14(214.38J7Ë��Ӝ��D次元城动漫zh"https://www.cycani.org
�

Hanime1.me-eu.kanade.tachiyomi.animeextension.zh.hanime1�
dhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-zh.hanime1-v14.7.apkzhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.zh.hanime1.png"14(214.78J.��澧���'
Hanime1.mezh"https://hanime1.me
�
iyf)eu.kanade.tachiyomi.animeextension.zh.iyf�
`https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-zh.iyf-v14.1.apkvhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.zh.iyf.png"14(214.18J-�������+	爱壹帆zh"https://www.iyf.tv
�
Nivod+eu.kanade.tachiyomi.animeextension.zh.nivod�
bhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-zh.nivod-v14.1.apkxhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.zh.nivod.png"14(214.18J/؜������	泥视频zh"https://www.nivod.cc
�
Xfani+eu.kanade.tachiyomi.animeextension.zh.xfani�
bhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-zh.xfani-v14.8.apkxhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.zh.xfani.png"14(214.88J8�������{稀饭动漫zh"https://anime.xifanacg.com
�
	Xiaoxintv/eu.kanade.tachiyomi.animeextension.zh.xiaoxintv�
fhttps://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/apk/aniyomi-zh.xiaoxintv-v14.1.apk|https://raw.githubusercontent.com/yuzono/anime-repo/refs/heads/repo/icon/eu.kanade.tachiyomi.animeextension.zh.xiaoxintv.png"14(214.18J2�ڤ���m小宝影院zh"https://xiaoxintv.cc